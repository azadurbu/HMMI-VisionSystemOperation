1. 바탕화면에 VisionSystemOperation.exe 마우스 오른쪽 클릭

2. 파일위치열기 클릭

3. 기존에 있던 VisionSystemOperation.exe, VisionSystemOperation_None PLC.exe(PLC 연결 버전 아님) 백업 복사(신규버전 실패 시 기존 버전으로 롤백)
 ex) VisionSystemOperation_20250609_bak

4. 복사 확인 후 신규 프로그램 패치


////////////////////////////////////English

1. Right-click VisionSystemOperation.exe on the desktop

2. Click Open File Location

3. Backup copy the existing VisionSystemOperation.exe, VisionSystemOperation_None PLC.exe (not the PLC connection version) (roll back to the existing version if the new version fails)

4. Patch the new program after confirming the copy
